var searchData=
[
  ['getavailableplaces_0',['getAvailablePlaces',['../class_flight.html#a00f2065f06fb0bc36447f84037b523a9',1,'Flight']]],
  ['getname_1',['getName',['../class_airport.html#a939b886a8a9675e22418f2c9a490bdcb',1,'Airport']]],
  ['gettransports_2',['getTransports',['../class_airport.html#a835313dca20b7907754090389471d65b',1,'Airport']]],
  ['gettransportssize_3',['getTransportsSize',['../class_airport.html#ae4bda878aabb603490eae99ab764bebd',1,'Airport']]]
];
