var searchData=
[
  ['checkifisavailable_0',['checkIfIsAvailable',['../class_plane.html#a7817bf96deb1c45d5ee2d8df4126487d',1,'Plane']]],
  ['company_1',['Company',['../class_company.html',1,'Company'],['../class_company.html#ae486b32b89f97a2953d6a0cf3eb7d9f6',1,'Company::Company()']]]
];
