var searchData=
[
  ['daysbetweendates_0',['daysBetweenDates',['../class_date.html#a6321d3d16f795ba7f70b9cc81ad55873',1,'Date']]],
  ['dayssince2020_1',['daysSince2020',['../class_date.html#a005261fb44316e2d8453d069a29fb453',1,'Date']]]
];
